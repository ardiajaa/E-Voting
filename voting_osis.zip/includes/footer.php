    <footer class="bg-white shadow-lg mt-8">
        <div class="max-w-6xl mx-auto px-4 py-4">
            <p class="text-center text-gray-600">&copy; <?php echo date('Y'); ?> OSIS <?php echo htmlspecialchars($settings['nama_sekolah'] ?? 'PILKETOS'); ?>. All rights reserved.</p>
        </div>
    </footer>
</body>
</html> 